#include <iostream>
#include <vector>

int main() {
    // declarando as variáveis
    int numeroCamisas = 0, contadorP = 0, contadorM = 0, camisasP, camisasM;

    // lendo o número de camisas, aplicando a condição de existência
    do {
        std::cout << "Digite o número de camisas entregues:\n";
        std::cin >> numeroCamisas;
    } while (numeroCamisas == 0);

    std::vector<int> tamanhoCamisas(numeroCamisas); // usando std::vector em vez de array

    for (int i = 0; i < numeroCamisas; i++) {
        std::cin >> tamanhoCamisas[i]; // lendo os tamanhos das camisas pedidas

        // atribuindo a quantidade de tipo de camisa pedidas
        if (tamanhoCamisas[i] == 1) {
            contadorP++;
        } else if (tamanhoCamisas[i] == 2) {
            contadorM++;
        }
    }

    std::cin >> camisasP; // verificando as quantidades reais de camisas P
    std::cin >> camisasM; // verificando as quantidades reais de camisas M;

    // dando a resposta com a verificação Expectativa x Realidade;
    if (contadorP == camisasP && contadorM == camisasM && numeroCamisas == camisasM + camisasP) {
        std::cout << "S" << std::endl;
    } else {
        std::cout << "N" << std::endl;
    }

    return 0;
}
