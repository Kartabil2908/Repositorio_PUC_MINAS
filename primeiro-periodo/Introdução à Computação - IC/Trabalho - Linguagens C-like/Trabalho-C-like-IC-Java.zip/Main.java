import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        // Declarando as variáveis
        int numeroCamisas = 0, contadorP = 0, contadorM = 0, camisasP, camisasM;

        // Criando um scanner para a entrada do usuário
        Scanner scanner = new Scanner(System.in);

        // Lendo o número de camisas, aplicando a condição de existência
        do {
            System.out.println("Digite o número de camisas entregues:");
            numeroCamisas = scanner.nextInt();
        } while (numeroCamisas == 0);

        // Declarando o array "tamanhoCamisas"
        int[] tamanhoCamisas = new int[numeroCamisas];

        for (int i = 0; i < numeroCamisas; i++) {
            tamanhoCamisas[i] = scanner.nextInt(); // Lendo os tamanhos das camisas pedidas

            // Atribuindo a quantidade de cada tipo de camisa pedida
            if (tamanhoCamisas[i] == 1) {
                contadorP++;
            }

            if (tamanhoCamisas[i] == 2) {
                contadorM++;
            }
        }

        camisasP = scanner.nextInt(); // Verificando as quantidades reais de camisas P
        camisasM = scanner.nextInt(); // Verificando as quantidades reais de camisas M

        // Dando a resposta com a verificação Expectativa x Realidade
        if (contadorP == camisasP && contadorM == camisasM && numeroCamisas == camisasM + camisasP) {
            System.out.println("S");
        } else {
            System.out.println("N");
        }

        // Fechando o scanner
        scanner.close();
    }
}
